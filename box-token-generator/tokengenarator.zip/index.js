
const BoxSDK = require('box-node-sdk');
var AWS = require("aws-sdk");
AWS.config.update({  region: "eu-west-2"});
var docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = async function  (event) {
  //const clientId = "uie27c6xniopg9wrcxywucg58t2emgs7";//event.queryStringParameters.clientId;
  const authCode=event.queryStringParameters.authCode;
  const clientId=event.queryStringParameters.clientId;
    var params = {
      TableName: "boxauth",
      KeyConditionExpression: "#clientId = :cid",
      ExpressionAttributeNames: {
        "#clientId": "clientId"
      },
      ExpressionAttributeValues: {
        ":cid":clientId
      }
    };
    console.log("Query starting.");
    
    var queryPromise = docClient.query(params).promise();
    let secret=''
    var tokens;
    await queryPromise.then(function(data) {
      secret = data.Items[0].clientSecret;
    });
    var sdk= new BoxSDK({
      clientID: clientId,
      clientSecret: secret});
      await sdk.getTokensAuthorizationCodeGrant(authCode, null, function(err, tokenInfo) {
        if (err) {
              console.log("error:"+err);
        }
        userToken = tokenInfo.accessToken;
        refreshToken = tokenInfo.refreshToken;
        tokens = {
          token: userToken,
          refreshToken:refreshToken
        };
        console.log(`tokens1: ${JSON.stringify(tokens, null, 2)}`);
      });
      const response = {
        statusCode: 200,
        headers: {
          "Access-Control-Allow-Origin" : "*" // Required for CORS support to work
        },
        body:JSON.stringify(tokens)
      };
      return response;
}
